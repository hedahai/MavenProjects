package org.king.example.loadbalancer;

import java.util.List;
import java.util.Random;

/**
 * 随机访问规则
 *
 */
public class RandomRule implements IRule {

	private ILoadBalancer loadBalancer;
	
	public RandomRule() {
    }
	
	public RandomRule(ILoadBalancer lb) {
		this.loadBalancer = lb;
    }
	
	@Override
	public IServer choose(Object key) {
		
		if (loadBalancer == null) {
            return null;
        }
		
		IServer server = null;
		
		int count = 0;
		
		//循环10次仍获取不到server ，直接返回null
		while( server == null && count++<10) {
			List<IServer> reachableServers = loadBalancer.getReachableServers();
	        int upCount = reachableServers.size();
	        
	        if(upCount == 0) {
	        	return null;
	        }
	        
	        Random random = new Random();
	        int index = random.nextInt(upCount);
	        server = reachableServers.get(index);
	        
	        //防止取到的server，被并发改了状态
	        if(server == null) {
	        	continue;
	        }
	        //再次判断取到的server是不是可用的
	        if(server.isAlive()) {
	        	return server;
	        }
	        server = null;
		}
        
		return server;
	}

	@Override
	public void setLoadBalancer(ILoadBalancer lb) {
		this.loadBalancer = lb;
	}

	@Override
	public ILoadBalancer getLoadBalancer() {
		return this.loadBalancer;
	}

}
