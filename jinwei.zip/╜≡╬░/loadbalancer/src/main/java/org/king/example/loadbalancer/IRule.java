package org.king.example.loadbalancer;

public interface IRule {
	
	/**
	 * 不同规则实现类可定义不同的负载均衡算法
	 * @param key
	 * @return
	 */
	IServer choose(Object key);
	
	void setLoadBalancer(ILoadBalancer lb);
	
	/**
	 * 获取负载均衡LoadBalancer,根据LoadBalancer可获取可用服务，服务状态等信息
	 * @return
	 */
	ILoadBalancer getLoadBalancer(); 

}
