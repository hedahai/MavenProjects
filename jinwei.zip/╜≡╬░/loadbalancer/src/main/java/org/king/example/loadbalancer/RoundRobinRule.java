package org.king.example.loadbalancer;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 轮询访问规则
 *
 */
public class RoundRobinRule implements IRule {
	
	private static AtomicInteger nextServerCyclicCounter;
	
	private ILoadBalancer loadBalancer;
	
	public RoundRobinRule() {
		nextServerCyclicCounter = new AtomicInteger(0);
    }
	
	public RoundRobinRule(ILoadBalancer lb) {
		this();
        setLoadBalancer(lb);
    }
	
	public IServer choose(ILoadBalancer lb,Object key) {
		
		if (loadBalancer == null) {
            return null;
        }
		IServer server = null;
		
		int count = 0;
		
		//循环10次仍获取不到server ，直接返回null
		while( server == null && count++<10) {
			
			List<IServer> reachableServers = lb.getReachableServers();
	        List<IServer> allServers = lb.getAllServers();
	        int upCount = reachableServers.size();
	        int serverCount = allServers.size();
	        
	        if ((upCount == 0) || (serverCount == 0)) {
	            return null;
	        }
			
	        int next = incrementAndGetModulo(upCount);
	        
	        server = allServers.get(next);
	        
	        if(server == null) {
	        	continue;
	        }
	        //再次判断取到的server是不是可用的
	        if(server.isAlive()) {
	        	return server;
	        }
	        server = null;
		}
        
		return server;
	}
	
	/**
	 * 原子取模运算
	 * @param modulo
	 * @return
	 */
	private int incrementAndGetModulo(int modulo) {
        for (;;) {
            int current = nextServerCyclicCounter.get();
            int next = (current + 1) % modulo;
            if (nextServerCyclicCounter.compareAndSet(current, next))
                return next;
        }
    }
	
	@Override
	public IServer choose(Object key) {
        return choose(getLoadBalancer(), key);
    }
	
	@Override
	public void setLoadBalancer(ILoadBalancer lb) {
		this.loadBalancer = lb;
	}

	@Override
	public ILoadBalancer getLoadBalancer() {
		return loadBalancer;
	}
	
	
}
