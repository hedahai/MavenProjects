//zhu-xx 2017-11-07对比form表单是否有数据变化
var mapFormMod = {};
//先将表单数据收集
function resetFormMod(arr1){
	mapFormMod = {};
	for(var i=0;i<arr1.length;i++){
		mapFormMod[arr1[i]] = $("#"+arr1[i]).serializeArrayAll();
	}
}
//进行数据对比
function checkFormMod(formNameArr){
	for(var i=0;i<formNameArr.length;i++){
		var formName = formNameArr[i];
		if($("#"+formName).serializeArrayAll().length>0){
			if($("#"+formName).serializeArrayAll().length != mapFormMod[formName].length){
				return false;
			}
			for(var j=0;j<mapFormMod[formName].length;j++){
				if($("#"+formName).serializeArrayAll()[j].name == mapFormMod[formName][j].name){
					if($("#"+formName).serializeArrayAll()[j].value != mapFormMod[formName][j].value){
						return false;
					}
				}
			}
		}
	}
	return true;
}
//多选框赋值
function getMultipleCodeList(codeData,codeArr,id,includeCode){
	
	var banarr = "";
	for(var j=0;j<$("#"+id)[0].length;j++){
		if($("#"+id)[0][j].disabled == true)
			banarr = banarr + $("#"+id)[0][j].value +",";
	}
	banarr = banarr.substring(0,banarr.length-1);
	
	var arr1 = codeData.split(',');
	var arr2 = codeArr;
	for(var i=0;i<arr2.length;i=i+2){
		$("#"+id+" option[value='"+arr2[i]+"']").detach();
		if(includeCode==true){
			$("#"+id).append("<option value='"+arr2[i]+"'>"+arr2[i]+"&nbsp"+arr2[i+1]+"</option>");
		}else{
			$("#"+id).append("<option value='"+arr2[i]+"'>"+arr2[i+1]+"</option>");
		}
		var banindex = banarr.indexOf(arr2[i]);
		if(banindex>=0){
			$("#"+id+" option[value='"+arr2[i]+"']").attr("disabled",true);
			$("#"+id).trigger('chosen:updated');
			continue;
		}
		var indexhas = arr1.indexOf(arr2[i]);
		if(indexhas>=0){
			$("#"+id+" option[value='"+arr2[i]+"']").attr("selected",true);
			$("#"+id).trigger('chosen:updated');
		}
	}
	$("#"+id).trigger('chosen:updated');
}

(function($, window) {
	MZ_FCUtil = {
		refreshGrid_scroll : function(table, data, render){
			//table构建开始
			var table = $(table);
			var tbd = $("tbody", table);
			tbd.remove();
			var valTbody = $("<tbody></tbody>");
			// var gridDiv = $("div[mz-grid='"+table.attr("id")+"']");//整体DIV
			// gridDiv.css("position","relative");
			// var scrollDiv = $("<div class=\"scrollDiv\"></div>");//滚动DIV
			// scrollDiv.css("overflow-y","auto");
			// scrollDiv.css("overflow-x","hidden");	
			// scrollDiv.height(gridDiv.attr("height"));
			
			// var valTable = $("<table class=\"table table-hover table-condensed table-striped datas\" style=\"margin-bottom: 0;\"></table>");
			// valTable.attr("pid",table.attr("id"));
			// var valThead = $("<thead></thead>");
			// var valTbody = $("<tbody></tbody>");
			// valTbody.addClass("h");
			
			// if(rowClick){
			// 	valTable.delegate("tr","click",function(e){
			// 		var $n = $(this);
			// 		var rowIndex = $n.attr("rowIndex");
			// 		var datasJson = {};
			// 		for(var i=0;i<data.cols.length;i++){
			// 			datasJson[data.cols[i]] = data.data[rowIndex][i];
			// 		};
			// 		$("td.select",$n.parent()).each(function(i){
			// 			$(this).removeClass("select");
			// 		});
			// 		$(">td",$n).each(function(i){
			// 			$(this).addClass("select");
			// 		});	
			// 		rowClick(rowIndex,datasJson);
			// 		e.stopPropagation();
			// 		return false;					
			// 	});				
			// };
			
			var cols = {};
			for (var i = 0; i < data.cols.length; i++) {
				cols[data.cols[i]] = i;
			}
			var thd = [];
			var keyc = [];
			var cdlst = [];
			var cmap = {};
			var stytd = [];//td 对齐样式
			var types = [];  //数字类型

			$("thead th[aw-colname]", table).each(function(i, n) {
				var n = $(n);
				//判断th下面有没有图片。如果有则跳过，如果没有则添加图片
				/*if(n.find("img").length==0){
					n.append("<img>");
				}*/
				thd.push(n.attr("aw-colname"));
				keyc.push(n.attr("aw-keycol"));
				stytd.push(n.attr("mz-styletd"));
				types.push(n.attr("text-type"));   //数字类型
				var awcl = n.attr("aw-codelist");
				if (typeof awcl != "undefined" && awcl) {
					awcl = awcl.toUpperCase();
				}
				cdlst.push(awcl);
				if (awcl && !cmap[awcl]) {
					cmap[awcl] = AW.getCodelistMap(awcl);
				}
			});
			// valThead.html($("thead", table).html());
			var list = data.data;
			for (var i = 0; i < list.length; i++) {
				var tr = $("<tr></tr>");
				
				for (var j = 0; j < thd.length; j++) {
					var td = $("<td></td>");
					if (stytd[j] === "center"){
						td.css("text-align","center");
					}else if (stytd[j] === "right"){
						td.css("text-align","right");
					}else {
						td.css("text-align","left");
					}
					
					var val = null;
					var coli = cols[thd[j]];
					var ttype = types[j];
					if (typeof coli == "undefined") {
						if (thd[j] == "rownum") {
							val = (data.pagenum - 1) * data.pagesize + i + 1;
						} else if (thd[j] == "checkbox") {
							var kc = keyc[j];
							val = $("<input type='checkbox' name='" + kc + "' style='margin:0px'/>");
							val.val(list[i][cols[kc]]);
						} else if (thd[j] == "radio") {
							var kc = keyc[j];
							val = $("<input type='radio' name='" + kc + "' style='margin:0px'/>");
							val.val(list[i][cols[kc]]);
						} 
					} else if(typeof ttype != "undefined") {
						//判断td中的数字类型
						if (ttype=="decimal"){
							var numval  = list[i][coli];
							if(numval>=0){
								//字体颜色绿色
								val = "<span style='color:green'>"+numval+"</span>"
							}else{
								val = "<span style='color:red'>"+numval+"</span>"
							}
						} else if(ttype=="per"){
							var numval = decimal(list[i][coli] * 100,2);
							if(numval>=0){
								val = "<span style='color:green'>"+numval+"%</span>"
							}else{
								val = "<span style='color:red'>"+numval+"%</span>"
							}
						}
						

					}else {
						val = list[i][coli];
						if (typeof cdlst[j] != "undefined" && cdlst[j] != null) {
							var tmpmap = cmap[cdlst[j]];
							if (tmpmap != null && val) {
								var vals = val.split(",");
								var txts = [];
								for (var vs = 0; vs < vals.length; vs++) {
									var tmpv = tmpmap[vals[vs]];
									if (typeof tmpv != "undefined") {
										txts.push(tmpv);
									}
								}
								val = txts.join(",");
							}
						}


					}
					var re = false;
					
					if (render) {
						re = render(td, val, typeof coli == "undefined" ? null : list[i][coli], i, thd[j]);
					}
					if (!re) {
						if (typeof val == "object") {
							td.append(val);
						} else {
							td.html(val + "");
						}
					}
					tr.append(td);
					tr.attr("rowIndex",i);					
				}
				valTbody.append(tr);
			}
			table.append(valTbody);
		}
	};
	window.MZ_FCUtil = MZ_FCUtil;
	
}(jQuery, window));
	