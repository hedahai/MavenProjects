package com.example.bank.transfer.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * 转账记录表
 * @author jinwei
 */
@Data
public class TransferRecord implements Serializable{

    private static final long serialVersionUID = 1L;

    private String id;

    /**
     * 转账单号
     */
    private String transferNum;

    /**
     * 转出账号id
     */
    private String fromAccountId;

    /**
     * 转出人姓名
     */
    private String fromAccountName;

    /**
     * 转出人账号
     */
    private String fromAccountNum;

    /**
     * 收款人账号Id
     */
    private String toAccountId;

    /**
     * 收款人姓名
     */
    private String toAccountName;

    /**
     * 收款人账号
     */
    private String toAccountNum;

    /**
     * 转账日期
     */
    private String transferDate;

    /**
     * 转账金额
     */
    private String transferAmount;

    /**
     * 转账状态
     */
    private String transferStatus;
}
