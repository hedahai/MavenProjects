package com.example.bank.transfer.mapper;


import com.example.bank.transfer.entity.TransferRecord;

import java.util.List;

public interface TransferRecordMapper {
    /**
     * 添加转账记录
     * @param transferRecord
     */
    void addTransferRecord(TransferRecord transferRecord);

    /**
     * 根据用户账户id查询转账记录
     * @param accountId
     * @return
     */
    List<TransferRecord> selectByAccountId(String accountId);
}
