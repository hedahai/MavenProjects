package com.example.bank.transfer.service;

import com.example.bank.transfer.entity.Accounts;
import com.example.bank.transfer.mapper.AccountsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AccountsService {

    @Autowired
    private AccountsMapper accountsMapper;

    @Transactional(readOnly = true)
    public List<Accounts> selectAllAccounts(){
        return accountsMapper.selectAllAccounts();
    }

    @Transactional(readOnly = false,rollbackFor = Exception.class)
    public Accounts addAccount(Accounts accounts){
        accountsMapper.addAccount(accounts);
        return accounts;
    }

    @Transactional(readOnly = false,rollbackFor = Exception.class)
    public void addAmount(String accountId,String amount){
        accountsMapper.addAmount(accountId,amount);
    }

    @Transactional(readOnly = false,rollbackFor = Exception.class)
    public void deductAmount(String accountId,String amount){
        accountsMapper.deductAmount(accountId,amount);
    }

}
