package com.example.bank.transfer.entity;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * 账户表
 * @author jinwei
 */
@Getter
@Setter
public class Accounts implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    /**
     * 客户姓名
     */
    private String name;

    /**
     * 姓名备注
     */
    private String nameComments;

    /**
     * 银行卡账号
     */
    private String accountNum;

    /**
     * 附加备注
     */
    private String comments;

    /**
     * 账户余额
     */
    private String accountBalance;

    /**
     * 余额单位
     */
    private String balanceUnit;

    /**
     * 账户类型
     */
    private String accountType;

    /**
     * 账户状态
     */
    private String accountStatus;
}
