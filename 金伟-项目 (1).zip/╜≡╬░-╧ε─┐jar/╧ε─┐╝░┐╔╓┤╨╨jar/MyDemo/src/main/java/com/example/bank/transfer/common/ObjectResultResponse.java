package com.example.bank.transfer.common;

public class ObjectResultResponse<T>{

    protected String msg;

    protected String code;

    protected boolean isSuccess;

    protected T result;

    public ObjectResultResponse() {
    }

    public T getResult() {
        return this.result;
    }

    public void setResult(T result) {
        this.result = result;
    }

    public static <T> ObjectResultResponse<T> createBySuccess() {
        ObjectResultResponse<T> resultResponse = new ObjectResultResponse();
        resultResponse.setIsSuccess(true);
        resultResponse.setCode("0000");
        return resultResponse;
    }

    public static <T> ObjectResultResponse<T> createBySuccessMessage(String msg) {
        ObjectResultResponse<T> resultResponse = new ObjectResultResponse();
        resultResponse.setIsSuccess(true);
        resultResponse.setCode("0000");
        resultResponse.setMsg(msg);
        return resultResponse;
    }

    public static <T> ObjectResultResponse<T> createBySuccess(T result) {
        ObjectResultResponse<T> resultResponse = new ObjectResultResponse();
        resultResponse.setIsSuccess(true);
        resultResponse.setCode("0000");
        resultResponse.setResult(result);
        return resultResponse;
    }

    public static <T> ObjectResultResponse<T> createBySuccess(String msg, T result) {
        ObjectResultResponse<T> resultResponse = new ObjectResultResponse();
        resultResponse.setIsSuccess(true);
        resultResponse.setCode("0000");
        resultResponse.setMsg(msg);
        resultResponse.setResult(result);
        return resultResponse;
    }

    public static <T> ObjectResultResponse<T> createByErrorCodeMessage(String errorCode, String errorMessage) {
        ObjectResultResponse<T> resultResponse = new ObjectResultResponse();
        resultResponse.setIsSuccess(false);
        resultResponse.setCode(errorCode);
        resultResponse.setMsg(errorMessage);
        return resultResponse;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public boolean isSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(boolean success) {
        isSuccess = success;
    }
}

