package com.example.bank.transfer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/bank")
public class AccountController {

    @RequestMapping(value = "/transferIndex")
    public String transferIndex(){
        return "transferIndex";
    }
}
