package com.example.bank.transfer.rest;

import com.example.bank.transfer.common.ObjectResultResponse;
import com.example.bank.transfer.entity.TransferRecord;
import com.example.bank.transfer.service.TransferRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.UUID;

@RestController
@RequestMapping(value = "/transferRecords")
public class TransferRecordRest {

    @Autowired
    private TransferRecordService transferRecordService;

    //每次进入转账页面，保存在转账表单隐藏域内
    @GetMapping(value = "/transferTokens")
    public synchronized ObjectResultResponse<String> getTokens(){
        String token = UUID.randomUUID().toString();
        ObjectResultResponse<String> resultResponse = new ObjectResultResponse<>();
        resultResponse.setResult(token);
        return resultResponse;
    }

    /**
     * 防止表单重复提交
     * @param transferRecord
     * @param httpRequest
     * @return
     */
    @PostMapping(value = "/records")
    public ObjectResultResponse addRecords(TransferRecord transferRecord, HttpServletRequest httpRequest){
        String token = (String)httpRequest.getSession().getAttribute("recordToken");
        //表单隐藏域保存的页面唯一的token
        String firstToken = (String)httpRequest.getAttribute("recordToken");

        //返回转账单号
        ObjectResultResponse<String> resultResponse = new ObjectResultResponse<>();

        if(StringUtils.isEmpty(token) || !token.equals(firstToken)){
            //第一次提交，刷新页面，切换用户等都会重新请求新的token
            httpRequest.getSession().setAttribute("recordToken",firstToken);
            transferRecordService.addTransferRecord(transferRecord);
            resultResponse.setMsg("转账成功!");
            return resultResponse;
        }else {
            //重复提交
            resultResponse.setMsg("转账成功!");
            return resultResponse;
        }
    }
}
