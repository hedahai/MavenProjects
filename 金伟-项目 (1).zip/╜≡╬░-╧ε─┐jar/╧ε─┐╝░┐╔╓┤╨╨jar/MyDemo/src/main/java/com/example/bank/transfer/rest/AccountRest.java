package com.example.bank.transfer.rest;

import com.example.bank.transfer.common.ObjectResultResponse;
import com.example.bank.transfer.entity.Accounts;
import com.example.bank.transfer.service.AccountsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/bank")
public class AccountRest {

    @Autowired
    private AccountsService accountsService;

    @GetMapping("/accounts")
    public ObjectResultResponse<List<Accounts>> getAccounts(){
        ObjectResultResponse<List<Accounts>> resultResponse = new ObjectResultResponse<>();
        List<Accounts> accountsList = accountsService.selectAllAccounts();
        resultResponse.setResult(accountsList);
        return resultResponse;
    }

    @PostMapping("/accounts")
    public ObjectResultResponse<Accounts> addAccounts(@RequestBody Accounts accounts){
        ObjectResultResponse<Accounts> resultResponse = new ObjectResultResponse<>();
        try{
            accountsService.addAccount(accounts);
        }catch (Exception e){
            e.printStackTrace();
            resultResponse.setResult(accounts);
            resultResponse.setMsg("新增失败！");
            return resultResponse;
        }
        resultResponse.setResult(accounts);
        resultResponse.setMsg("新增成功！");
        return resultResponse;
    }

}
