package com.example.bank.transfer.mapper;

import com.example.bank.transfer.entity.Accounts;

import java.util.List;

public interface AccountsMapper {

    /**
     * 新增账户
     * @param accounts 账户
     * @return 账户
     */
    void addAccount(Accounts accounts);

    /**
     * 查询所有账户信息
     * @return
     */
    List<Accounts> selectAllAccounts();

    /**
     * 向账户增加金额
     * @param accountId
     * @param amount
     */
    void addAmount(String accountId,String amount);

    /**
     * 向账户扣减金额
     * @param accountId
     * @param amount
     */
    void deductAmount(String accountId,String amount);
}
