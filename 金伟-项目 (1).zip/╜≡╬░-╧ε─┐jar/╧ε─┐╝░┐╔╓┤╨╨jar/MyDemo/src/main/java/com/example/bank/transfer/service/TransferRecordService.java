package com.example.bank.transfer.service;

import com.example.bank.transfer.entity.TransferRecord;
import com.example.bank.transfer.mapper.TransferRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TransferRecordService {

    @Autowired
    private TransferRecordMapper transferRecordMapper;

    @Autowired
    private AccountsService accountsService;

    @Transactional(readOnly = true)
    public List<TransferRecord> selectByAccountId(String accountId){
        return transferRecordMapper.selectByAccountId(accountId);
    }

    @Transactional(readOnly = false,rollbackFor = Exception.class)
    public TransferRecord addTransferRecord(TransferRecord transferRecord){
        transferRecordMapper.addTransferRecord(transferRecord);
        accountsService.addAmount(transferRecord.getToAccountId(),transferRecord.getTransferAmount());
        accountsService.deductAmount(transferRecord.getFromAccountId(),transferRecord.getTransferAmount());
        return transferRecord;
    }

}
