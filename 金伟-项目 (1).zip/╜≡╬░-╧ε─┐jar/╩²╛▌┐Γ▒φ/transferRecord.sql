
create table TRANSFER_RECORD
(
  id                VARCHAR2(255) not null,
  from_account_id   VARCHAR2(255),
  from_account_name VARCHAR2(255),
  from_account_num  VARCHAR2(255),
  to_account_id     VARCHAR2(255),
  to_account_name   VARCHAR2(255),
  to_account_num    VARCHAR2(255),
  transfer_date     VARCHAR2(255),
  transfer_amount   VARCHAR2(255),
  transfer_status   VARCHAR2(25),
  transfer_num      VARCHAR2(25)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;
alter table TRANSFER_RECORD
  add constraint PK_TRANSFER_RECORD primary key (ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255;

commit;

