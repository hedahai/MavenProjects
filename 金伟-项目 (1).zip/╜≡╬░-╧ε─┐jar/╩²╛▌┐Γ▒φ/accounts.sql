create table BANK_ACCOUNT
(
  id              VARCHAR2(255) not null,
  name            VARCHAR2(255),
  name_comments   VARCHAR2(255),
  account_num     VARCHAR2(255),
  comments        VARCHAR2(2550),
  account_balance VARCHAR2(255),
  balance_unit    VARCHAR2(25),
  account_type    VARCHAR2(25),
  account_status  VARCHAR2(25)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table BANK_ACCOUNT
  add constraint PK_BANK_ACCOUNT primary key (ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
commit;
insert into BANK_ACCOUNT (id, name, name_comments, account_num, comments, account_balance, balance_unit, account_type, account_status)
values ('1', '����', '��������', '111111111', '��', '100000', 'CNY', '�����˻�', 'ʹ����');
insert into BANK_ACCOUNT (id, name, name_comments, account_num, comments, account_balance, balance_unit, account_type, account_status)
values ('2', '����', '���Ľ���', '222222', '�ޱ�ע', '2000', 'CNY', '��ǿ��˻�', 'ʹ����');
commit;

