package gct.digital;

import java.util.ArrayList;
import java.util.Map;
import java.util.Random;


public class Rule {
	

   public String random(Map<String,String> serverMap) {
	   System.out.println("Random Rule in use");
	   if(serverMap.size() == 0){
		   return "0";
	   }
       ArrayList<String> srvIdList = new ArrayList<String>();
       srvIdList.addAll(serverMap.keySet());
       Random random = new Random();
       int rdm = random.nextInt(srvIdList.size());
       String server = srvIdList.get(rdm);
       return serverMap.get(server);
       
   }

   public String roundRobin(Map<String,String> serverMap, Integer pos) {
	   System.out.println("RoundRobin Rule in use");
	   if(serverMap.size() == 0){
		   return "0";
	   }
	   String server = null;
       ArrayList<String> srvIdList = new ArrayList<String>();
       srvIdList.addAll(serverMap.keySet());
       synchronized(pos){
           if (pos>=srvIdList.size()){
               return "out";
           }
           server=srvIdList.get(pos);
       }
       return  serverMap.get(server);
   }
   
}
