package gct.digital;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class App {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws FileNotFoundException {
		System.out.print(Utils.showHelpInfo());
		String type = "Random";
		String ifExit = "No";
		ELB elb = new ELB();
		Map<String, String> serverMap = elb.serverMap;
		
		while ("No".equalsIgnoreCase(ifExit)) {
			System.out.println("Please input command:");
			Scanner scanner = new Scanner(System.in);
			String str = scanner.nextLine();
			switch(str){
			case "1":
				System.out.println("ELB starts, Random is used as Load Banlancer Rule");
				type = "Random";
				Rule rule = new Rule();
				rule.random(serverMap);
				System.out.println("The number of instances are in service: " + serverMap.size());
				break;
			case "2":
				System.out.println("Start 3 elb instances with AppEngine configured");
				ArrayList<String> srvListAll = elb.getAllServers();
				for (String s : srvListAll) {
					elb.register(s);
				}
				System.out.println("The number of instances are in service: " + serverMap.size());
				break;
			case "3":
				System.out.println("Kill one elb instance randomly");
				if (serverMap.size() == 0) {
					System.out.println("No instance is in service");
				}else{
					ArrayList<String> srvList = new ArrayList<String>();
					srvList.addAll(serverMap.keySet());
					Random random = new Random();
					int rdm = random.nextInt(srvList.size());
					String server = srvList.get(rdm);
					elb.deRegister(server);
					System.out.println("The number of instances are in service: " + serverMap.size());
				}
				break;
			case "4":
				System.out.println("Statr one new elb instance");
				ArrayList<String> srvListAll4 = elb.getAllServers();
				ArrayList<String> srvListCur4 = new ArrayList<String>();
				ArrayList<String> srvList4 = new ArrayList<String>();
				srvListCur4.addAll(serverMap.keySet());
				for (int i = 0; i < srvListAll4.size(); i++) {
					if (!srvListCur4.contains(srvListAll4.get(i))) {
						srvList4.add(srvListAll4.get(i));
					}
				}
				Random random4 = new Random();
				int rdm4 = random4.nextInt(srvList4.size());
				String server4 = srvList4.get(rdm4);
				System.out.println(server4);
				elb.register(server4);
				System.out.println("The number of instances are in service: " + serverMap.size());
				break;
			case "5":
				System.out.println("Change Load Balance Rule of ELB");
				System.out.println("What is the new Balance Rule? Please choose Random or RoundRobin?");
				break;
			case "6":
				System.out.println("Show Status of ELB and available eas Servers");
				if (elb == null) {
					System.out.println("ELB not started...");
				} else {
					System.out.println("ELB is in service...");
					System.out.println("The number of instances are in service: " + serverMap.size());
				}
				break;
			case "7":
				System.out.println("send a /customer request to ELB,and display the output from AppEngine");
				Rule rule7 = new Rule();
				String eas_in_service = null;
				if("Random".equalsIgnoreCase(type)){
					eas_in_service = rule7.random(serverMap);
				}else if("RoundRobin".equalsIgnoreCase(type)){
					eas_in_service = rule7.roundRobin(serverMap,1);
				}
				System.out.println(eas_in_service);
				break;
			case "8":
				System.out.println("Exit System succeed");
				ifExit = "Yes";
				break;
			case "RoundRobin":
				System.out.println("ELB Load Banlancer Rule is RoundRobinRule");
				type = "RoundRobin"; 
				break;
			case "Random":
				System.out.println("ELB Load Banlancer Rule is Random");
				type = "Random"; 
				break;
			default:
				System.out.print(Utils.showHelpInfo());
			}
		}
	}
}
